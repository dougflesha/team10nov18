<?php if ( ! defined( 'ABSPATH' ) ) { die; } // Cannot access pages directly.
// ===============================================================================================
// -----------------------------------------------------------------------------------------------
// METABOX OPTIONS
// -----------------------------------------------------------------------------------------------
// ===============================================================================================
$options      = array();

// -----------------------------------------
// Page Metabox Options                    -
// -----------------------------------------
$options[]    = array(
  'id'        => 'product_custom_post_type',
  'title'     => 'Short Description About the product',
  'post_type' => 'products',
  'context'   => 'normal',
  'priority'  => 'default',
  'sections'  => array(

    // begin: a section
    array(
      'name'  => 'short_description',

      // begin: fields
      'fields' => array(

        // begin: a field
         array(
          'id'    => 'short_title',
          'type'  => 'text',
          //'title' => 'Short Details',
        ),
        array(
          'id'    => 'short_detail',
          'type'  => 'wysiwyg',
          //'title' => 'Short Details',
        ),
        
        
      ), // end: fields
    ), // end: a section

  ),
);








// -----------------------------------------
// Page Side Metabox Options               -
// -----------------------------------------


// -----------------------------------------
// Post Metabox Options                    -
// -----------------------------------------


CSFramework_Metabox::instance( $options );
