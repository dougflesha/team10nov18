<?php if ( ! defined( 'ABSPATH' ) ) { die; } // Cannot access pages directly.
// ===============================================================================================
// -----------------------------------------------------------------------------------------------
// FRAMEWORK SETTINGS
// -----------------------------------------------------------------------------------------------
// ===============================================================================================
$settings      = array(
  'menu_title' => 'Theme Options',
  'menu_type'  => 'add_theme_page',
  'menu_slug'  => 'rws-framework',
  'ajax_save'  => true,
  );

// ===============================================================================================
// -----------------------------------------------------------------------------------------------
// FRAMEWORK OPTIONS
// -----------------------------------------------------------------------------------------------
// ===============================================================================================
/**

**/
$options        = array();



// ----------------------------------------
// a general section -
// ----------------------------------------
$options[]      = array(
  'name'        => 'general',
  'title'       => 'General',
  'icon'        => 'fa fa-cog',

  // begin: fields
  'fields'      => array(

    array(
      'id'        => 'demo_site_title', 
      'title'     => 'Demo Site Title',
      'type'      => 'text',
      'default'   => 'Balangaun Homestay Ilam',
      'desc'      => 'Enter value to change site title'
      ),

    array(
      'id'        => 'site_logo',
      'type'      => 'image',
      'title'     => 'Logo',
      'desc'      => 'Click add image to change site logo.',
      'help'      => 'This option enable us to change site header logo.'
      ),

    array(
      'id'         => 'site_copyright',
      'type'       => 'textarea',
      'title'      => 'Copyright',
      'attributes' => array(
        'style'    => 'width: 100%;',
        ),
      'desc'       => 'Enter CopyRight text to show in footer.'      
      ),

  ), // end: fields
  );

/**

**/
//-------------------------------------
//----- social media options-----------
//-------------------------------------
/**

**/

// ------------------------------



/**

**/
// ----------------------------------------







/**

**/

/**

**/
//-------------------------------------------
//---------- Footer Section------------------
//-------------------------------------------

$options[]      = array(
  'name'        => 'footer',
  'title'       => 'Footer',
  'icon'        => 'fa fa-th',

  // begin: section
  'sections'      => array(

    array(
      'name'              => 'footer_widget_1',
      'title'           => 'Footer Widget 1',
      'fields'          => array(

        array(
          'id'          => 'footer_widget_1_title',
          'title'       => 'Title',
          'type'        => 'text',
          ),        

        array(
          'id'          => 'footer_widget_1_desc',
          'title'       => 'Description',
          'type'        => 'textarea',
          ),
        array(
          'id'          => 'footer_widget_1_tel',
          'title'       => 'Tel',
          'type'        => 'text',
          ),
        array(
          'id'          => 'footer_widget_1_fax',
          'title'       => 'Fax',
          'type'        => 'text',
          ),
         array(
          'id'          => 'footer_widget_1_email_by_department',
          'title'       => 'Email by Department',
          'type'        => 'textarea',
          ),

        ),
      ),

    
    

    array(   

      'name'              => 'footer_widget_4',
      'title'           => 'Social Media  Widget',
      'fields'          => array(

        array(
          'id'          => 'social_media_title',
          'title'       => 'Title',
          'type'        => 'text',
          ),        

        //array(

          /*'id'              => 'social_links',
          'type'            => 'group',
          'title'           => 'Social Links',
          'button_title'    => 'Add New',
          'accordion_title' => 'Add New Link',
          'fields'          => array(*/

            array(
              'id'          => 'fb_link',
              'type'        => 'text',
              'title'       => 'Facebook Link',
              ),

             array(
              'id'          => 'tw_link',
              'type'        => 'text',
              'title'       => 'Twitter Link',
              ),

            array(
              'id'          => 'g_link',
              'type'        => 'text',
              'title'       => 'Google+ Link',
              ),

            array(
              'id'          => 'pin_link',
              'type'        => 'text',
              'title'       => 'Pinterest Link',
              ),
			
			array(
			    'id'	    =>'youtube_link',
				'type'      =>'text',
				'title'     =>'Youtube Link',
				),
			
			array(
			    'id'	    =>'instagram_link',
				'type'      =>'text',
				'title'     =>'Instagram Link',
				),
           /* array(
              'id'          => 'site_s_icon',
              'type'        => 'icon',
              'title'       => 'Social Network fav-icon',
              ),           

            array(
              'id'          => 'site_s_links',
              'type'        => 'text',
              'title'       => 'Social Network Link',
              ),*/
            

            
          
          ),


),

  ), // end: sectiom
);


CSFramework::instance( $settings, $options );
