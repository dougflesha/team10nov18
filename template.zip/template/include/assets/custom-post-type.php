<?php 
if( !function_exists( 'product_custom_post_type' )){
	function product_custom_post_type(){
		$labels = array(
			'name'               => _x( 'sliders', 'goodsheetmetal' ),
			'singular_name'      => _x( 'slider', 'goodsheetmetal' ),
			'menu_name'          => _x( 'Our sliders', 'admin menu', 'goodsheetmetal' ),
			'add_new'            => _x( 'Add New slider', 'book', 'goodsheetmetal' ),
			'add_new_item'       => __( 'Add New sliders', 'goodsheetmetal' ),
			'new_item'           => __( 'New slider', 'goodsheetmetal' ),
			'edit_item'          => __( 'Edit slider', 'goodsheetmetal' ),
		);

		$args = array(
			'labels'			=> $labels,
			'description'        => __( 'Custom Post type for sliders', 'goodsheetmetal' ),
			'public'             => true,
			'publicly_queryable' => true,
			'show_ui'            => true,
			'show_in_menu'       => true,
			'query_var'          => true,
			'rewrite'            => array( 'slug' => 'sliders' ),
			'capability_type'    => 'post',
			'has_archive'        => true,
			'hierarchical'       => false,
			'menu_position'      => null,
			'supports'           => array( 'title', 'editor', 'thumbnail', 'comments'),
			'taxonomies' 		=> array('post_tag','category')
		);
		register_post_type('sliders',$args);

	}
	add_action( 'init','product_custom_post_type' );
}


if( !function_exists( 'service_custom_post_type' )){
	function service_custom_post_type(){
		$labels = array(
			'name'               => _x( 'Photos', 'goodsheetmetal' ),
			'singular_name'      => _x( 'Photo', 'goodsheetmetal' ),
			'menu_name'          => _x( 'Our Photos', 'admin menu', 'goodsheetmetal' ),
			'add_new'            => _x( 'Add New Photo', 'book', 'goodsheetmetal' ),
			'add_new_item'       => __( 'Add New Photos', 'goodsheetmetal' ),
			'new_item'           => __( 'New Photo', 'goodsheetmetal' ),
			'edit_item'          => __( 'Edit Photo', 'goodsheetmetal' ),
		);

		$args = array(
			'labels'			=> $labels,
			'description'        => __( 'Custom Post type for Photos', 'goodsheetmetal' ),
			'public'             => true,
			'publicly_queryable' => true,
			'show_ui'            => true,
			'show_in_menu'       => true,
			'query_var'          => true,
			'rewrite'            => array( 'slug' => 'Photos' ),
			'capability_type'    => 'post',
			'has_archive'        => true,
			'hierarchical'       => false,
			'menu_position'      => null,
			'supports'           => array( 'title', 'editor', 'thumbnail', 'comments'),
			'taxonomies' 		=> array('post_tag','category')
		);
		register_post_type('Photos',$args);

	}
	add_action( 'init','service_custom_post_type' );
}
?>