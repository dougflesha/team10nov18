<div class='sidebar'>
	<!-- Widget -->
	<div class='widget'>
		<h2 class='custom-color'>Our rooms</h2>
		<ul>
			<li><a href='#'>Superior Double Room</a></li>
			<li><a href='#'>Single room</a></li>
			<li><a href='#'>Double apartman</a></li>
			<li><a href='#'>Room for six</a></li>
		</ul>
	</div>
	<!-- Widget -->
	<div class='widget'>
		<h2 class='custom-color'>Things to do</h2>
		<ul>
			<li><a href='#'>Superior Double Room</a></li>
			<li><a href='#'>Single room</a></li>
			<li><a href='#'>Double apartman</a></li>
			<li><a href='#'>Room for six</a></li>
		</ul>
	</div>
	<!-- Widget -->
	<div class='widget'>
		<h2 class='custom-color'>Gallery</h2>
		
		<div class='gallery sidebar-gallery'>
    		<?php
				// Load images from Slider Directory
				$dirname = "design/gallery/";
				$images = glob($dirname."*.jpg");

				$i = 1;
				
				foreach($images as $image) {
					echo "<a href='".$image."' class='img-wrapper'><img src='".$image."' alt='gallery' /></a>";
					if ($i == 6) {
						break;
					}
					$i++;
				}
			?>
		</div>
	</div>
	<div class='cleaner'></div>
</div>