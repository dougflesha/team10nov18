<?php

// Change GPS for your hotel
$hotel_gps_latitude = '-27.46670265';
$hotel_gps_longtitude = '153.02947542';

// Required functions
require_once('php/functions.php');
?>

<!DOCTYPE html>
<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="en" lang="en">

  <!-- Head -->
  <head>
    <meta http-equiv="Content-Type" content="text/html; charset=utf-8" /> 
    <meta name="Keywords" content="hotel html" />
    <meta name="Description" content="Free hotel html template." />
    <meta name="author" content="HipstaCowboys.com" />
    <meta name="robots" content="index, nofollow" />
    <meta name="googlebot" content="index, nofollow" />

    <meta name="viewport" content="initial-scale = 1.0,maximum-scale = 1.0" />
    
    <!-- Social media meta -->
    <meta property="og:title" content="Title for Facebook" />
    <meta property="og:image" content="Path to image for Facebook" />
    <meta property="og:description" content="Description" />
    <meta property="og:site_name" content="Hotheme.co" />
    
    <link href="design/favicon.ico" rel="icon" type="image/ico" />
    
    <!-- Font -->
    <link href='http://fonts.googleapis.com/css?family=Roboto:700,400,300' rel='stylesheet' type='text/css' />

    <!-- Javascript -->
    <script src="lib/jquery.js"></script>
    <script src='lib/jquery-ui.js'></script>
    <script src='lib/jquery-form.js'></script>
    	<!-- Maps -->
    	<script type="text/javascript" src="http://maps.google.com/maps/api/js?sensor=false"></script>
    	<!-- Gallery -->
    	<script type="text/javascript" src="lib/magnific.js"></script>
	<!-- Custom script -->
	<script type="text/javascript" src="lib/script.js"></script>

    <!-- CSS -->
    <link href="css/general.css" rel="stylesheet" type="text/css" />
    <link href="css/category.css" rel="stylesheet" type="text/css" />
    <link href="css/contact.css" rel="stylesheet" type="text/css" />
    <link href="css/detail.css" rel="stylesheet" type="text/css" />
    <link href="css/reservation.css" rel="stylesheet" type="text/css" />
		<!-- Gallery -->
    	<link href="css/magnific.css" rel="stylesheet" type="text/css" />

    <title>News Portal</title>
  </head>

  <!-- Body -->
  <body>
    <!-- Message showed when user subscribe for a newsletter -->
    <?php if (isset($_SESSION['message'])) {
        echo "
        <div class='message custom-color-back'>
          <div class='wrapper'>
            <img src='design/icons/success.png' alt='success' />
            <p>". $_SESSION['message'] ."</p>
          </div>
        </div>
        <div class='message-mobile custom-color-back'>
          <div class='wrapper'>
            <img src='design/icons/success.png' alt='success' />
            <p>". $_SESSION['message'] ."</p>
          </div>
        </div>";

        unset($_SESSION['message']);
    }
    ?>

    <div class='wrapper'>
	    <!-- Header -->
	    <div class='header'>
	    	<a href='index.php' class='logo'><img src='design/logo.png' alt='logo' /></a>
	    	<a href='#menu-wrapper' class='menu-trigger'>Menu</a>
            <div class='menu-wrapper' id='menu-wrapper'>
	    		<ul class='menu'>
	    			<li><a href='index.php'>Home<br /><span class='grey'>Welcome</span></a></li>
	    			<li><a href='category.php'>International<br /><span class='grey'>Around the world</span></a></li>
	    			<li><a href='gallery.php'>Sports<br /><span class='grey'>Entertainment</span></a></li>
	    			<li><a href='things-to-do.php'>Technology<br /><span class='grey'>Development</span></a></li>
	    			<li><a href='contact.php'>Contact<br /><span class='grey'>Reach us</span></a></li>
	    			<li class='reservation-btn custom-color-btn-back'><a href='reservation.php'>Sign in<br /><span class='grey'>Exclusive news</span></a></li>
	    		</ul>
	    	</div>
	    	<div class='cleaner'></div>
		</div>