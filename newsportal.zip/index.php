<?php


session_start();

// Header
require_once('header.php'); ?>
	    
	    <!-- Photo slider -->
	    <div class='slider img-wrapper'>
			<?php
				// Load images from Slider Directory
				$dirname = "design/slider/";
				$images = glob($dirname."*.jpg");

				$i = 1;
				
				foreach($images as $image) {
					if ($i == 1) {
						echo "<img src='".$image."' alt='photo' class='active'/>";
					}	else {
						echo "<img src='".$image."' alt='photo' />";
					}

					$i++;
				}
			?>
	    </div>
	    
	    <!-- Welcome -->
	    <div class='welcome'>
	    	<div class='welcome-wrapper'>
		    	<h1>Welcome to Hotheme</h1>
		    	<p>Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum. 

	Sed ut perspiciatis unde omnis iste natus error sit voluptatem accusantium doloremque laudantium, totam rem aperiam, eaque ipsa quae ab illo inventore veritatis et quasi architecto beatae vitae dicta sunt explicabo. Nemo enim ipsam voluptatem quia voluptas sit aspernatur aut odit aut fugit, sed quia consequuntur magni dolores eos qui ratione voluptatem sequi nesciunt. Neque porro quisquam est, qui dolorem ipsum quia dolor sit amet, consectetur, adipisci velit, sed quia non numquam eius modi tempora incidun</p>
		    </div>
	    	<div class='facilities'>
	    		<h2 class='custom-color'>Facilities</h2>
	    		<ul>
	    			<li><img src='design/icons/check.png' alt='check' />100 luxury guest rooms</li>
	    			<li><img src='design/icons/check.png' alt='check' />Coctail bar</li>
	    			<li><img src='design/icons/check.png' alt='check' />2 restaurants</li>
	    			<li><img src='design/icons/check.png' alt='check' />Indoor & outdoor pool</li>
	    			<li><img src='design/icons/check.png' alt='check' />Free wi-fi everywhere</li>
	    			<li><img src='design/icons/check.png' alt='check' />Quest parking</li>
	    		</ul>
	    	</div>
	    </div>
	    
	    <!-- Middle part with testemonials and gallery -->
	    <div class='middle'>
			<div class='testemonials'>
				<div class='testemonial'>
					<div class='img-wrapper'>
						<img src='design/testemonials/01.jpg' alt='testimonial' />	
					</div>
					<span class='custom-color'>Peter Gregory</span>
					<p>Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor.</p>
				</div>
				<div class='testemonial'>
					<div class='img-wrapper'>
						<img src='design/testemonials/02.jpg' alt='testimonial' />	
					</div>
					<span class='custom-color'>Jane Foster</span>
					<p>Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor.</p>
				</div>
			</div>
			<div class='gallery content-gallery'>
				<?php
					// Load images from Slider Directory
					$dirname = "design/gallery/";
					$images = glob($dirname."*.jpg");

					$i = 1;
					
					foreach($images as $image) {
						if ($i < 7) {
							echo "<a href='".$image."'><img src='".$image."' alt='gallery'></a>";
						}	else {
							break;
						}

						$i++;
					}
				?>	
			</div>
			<div class='cleaner'></div>
	    </div>

	    <!-- Footer -->
	    <?php require('footer.php'); ?>
	    
    </div>
    
  </body>
</html>