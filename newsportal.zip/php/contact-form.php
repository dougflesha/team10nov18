<?php
session_start();

// Redirect back
Header('Location: http://'. $_SERVER['HTTP_HOST'] . '/');
echo "<meta charset='utf-8'>";  

// Loading variables from form
$name = $_POST['contact-name'];
$email = $_POST['contact-email'];
$message = $_POST['contact-message'];

// EMAIL TO HOTEL CREW
$headers = 'From: '. $name . '<' . $email . '>' . "\r\n" .
    'Reply-To: '. $name . '<' . $email . '>' . "\r\n" .
    'X-Mailer: PHP/' . phpversion();
$subject = 'Message';
$message = 'Name: ' . $name . '
Email: ' . $email . '

' . $message;

$to = 'your@email';

// Send mail
mail($to,$subject,$message,$headers);
// END OF EMAIL TO HOTEL CREW
// ---------------------

// SET message for guest after he send form
$_SESSION['message'] = 'Thanks for your message.';

exit();

?>