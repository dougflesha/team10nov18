<?php
session_start();

// Redirect back
Header('Location: http://'. $_SERVER['HTTP_HOST'] . '/');
echo "<meta charset='utf-8'>";  

// Loading variables from form
$room = $_POST['reservation-room'];
$checkin = $_POST['reservation-checkin'];
$checkout = $_POST['reservation-checkout'];
$people = $_POST['reservation-people'];

$name = $_POST['reservation-name'];
$email = $_POST['reservation-email'];
$phone = $_POST['reservation-phone'];
$message = $_POST['reservation-message'];

// EMAIL TO CLIENT
// SET info to email
	// From in format NAME <email>
	$from = 'Hotheme.co <your@email>';

	// Reply to in format NAME <email>
	$reply = 'Hotheme.co <your@email>';

	// Subject
	$subject = 'Reservation alert';

	// Message
	$message = 'Hi,
	this is test.

	Is it below?

	Your Hotheme.co
	';
//

$to = $email;
$headers = 'From: '. $from . "\r\n" .
    'Reply-To: '. $reply . "\r\n" .
    'X-Mailer: PHP/' . phpversion();
// Send mail
mail($to,$subject,$message,$headers);
// END OF EMAIL TO CLIENT
// ---------------------

// EMAIL TO RESERVATION CREW
$message = $_POST['reservation-message'];
$headers = 'From: '. $name . '<' . $email . '>' . "\r\n" .
    'Reply-To: '. $name . '<' . $email . '>' . "\r\n" .
    'X-Mailer: PHP/' . phpversion();
$subject = 'Reservation for room #' . $room;
$message = 'Name: ' . $name . '
Room: #' . $room . '

Check in: ' . $checkin . '
Check out: ' . $checkout . '
Number of people: ' . $people . '

Email: ' . $email . '
Phone: ' . $phone . '

' . $message;

$to = 'your@email';

// Send mail
mail($to,$subject,$message,$headers);
// END OF EMAIL TO RESERVATION CREW
// ---------------------

// SET message for guest after he send form
$_SESSION['message'] = 'Thanks for your reservation. Wait for confirmation.';

exit();

?>