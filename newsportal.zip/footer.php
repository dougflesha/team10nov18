<div class='footer custom-color-back'>
			<div class='directions'>
				<div class='map' id='footer-map'></div>

				<!-- Embed map -->
					<script>
						function initialize() {
						  var myLatlng = new google.maps.LatLng(<?php echo $hotel_gps_latitude.",".$hotel_gps_longtitude; ?>);
						  var mapOptions = {
						    zoom: 13,
						    center: myLatlng,
						    scrollwheel: false
						  }
						  var map = new google.maps.Map(document.getElementById('footer-map'), mapOptions);

						  var marker = new google.maps.Marker({
						      position: myLatlng,
						      map: map,
						      title: 'Hello World!'
						  });
						}

						google.maps.event.addDomListener(window, 'load', initialize);

					</script>

				<p><strong>Ground Floor/349</strong><br />
				Queen St, Brisbane City <br />
				QLD 4000
				<br /><a href='contact.php'>Full directions</a>
				</p>
			</div>
			<div class='wheater'>
				<div class='day'>
					<div class='img-wrapper'>
						<?php
						// Wheather status
						$wheater = 'cloudy';

						if ($wheater == 'sun') { $wheater_icon = 0;	}
						else if ($wheater == 'suncloudy') { $wheater_icon = 40; }
						else if ($wheater == 'cloudy') { $wheater_icon = 80; }
						else if ($wheater == 'rain') { $wheater_icon = 120; }
						else if ($wheater == 'snow') { $wheater_icon = 160; }

						echo "<img src='design/icons/wheater.png' alt='wheater' style='left: -".$wheater_icon."px;'/>";
						?>
					</div>
					<div class='temperature'>28°</div>
					<p>Fri</p>
				</div>
				<div class='day'>
					<div class='img-wrapper'>
						<?php
						// Wheather status
						$wheater = 'suncloudy';

						if ($wheater == 'sun') { $wheater_icon = 0;	}
						else if ($wheater == 'suncloudy') { $wheater_icon = 40; }
						else if ($wheater == 'cloudy') { $wheater_icon = 80; }
						else if ($wheater == 'rain') { $wheater_icon = 120; }
						else if ($wheater == 'snow') { $wheater_icon = 160; }

						echo "<img src='design/icons/wheater.png' alt='wheater' style='left: -".$wheater_icon."px;'/>";
						?>
					</div>
					<div class='temperature'>21°</div>
					<p>Sat</p>
				</div>
				<div class='day'>
					<div class='img-wrapper'>
						<?php
						// Wheather status
						$wheater = 'snow';

						if ($wheater == 'sun') { $wheater_icon = 0;	}
						else if ($wheater == 'suncloudy') { $wheater_icon = 40; }
						else if ($wheater == 'cloudy') { $wheater_icon = 80; }
						else if ($wheater == 'rain') { $wheater_icon = 120; }
						else if ($wheater == 'snow') { $wheater_icon = 160; }

						echo "<img src='design/icons/wheater.png' alt='wheater' style='left: -".$wheater_icon."px;'/>";
						?>
					</div>
					<div class='temperature'>28°</div>
					<p>Sun</p>
				</div>
				<div class='day'>
					<div class='img-wrapper'>
						<?php
						// Wheather status
						$wheater = 'sun';

						if ($wheater == 'sun') { $wheater_icon = 0;	}
						else if ($wheater == 'suncloudy') { $wheater_icon = 40; }
						else if ($wheater == 'cloudy') { $wheater_icon = 80; }
						else if ($wheater == 'rain') { $wheater_icon = 120; }
						else if ($wheater == 'snow') { $wheater_icon = 160; }

						echo "<img src='design/icons/wheater.png' alt='wheater' style='left: -".$wheater_icon."px;'/>";
						?>
					</div>
					<div class='temperature'>25°</div>
					<p>Mon</p>
				</div>
				<div class='day'>
					<div class='img-wrapper'>
						<?php
						// Wheather status
						$wheater = 'rain';

						if ($wheater == 'sun') { $wheater_icon = 0;	}
						else if ($wheater == 'suncloudy') { $wheater_icon = 40; }
						else if ($wheater == 'cloudy') { $wheater_icon = 80; }
						else if ($wheater == 'rain') { $wheater_icon = 120; }
						else if ($wheater == 'snow') { $wheater_icon = 160; }

						echo "<img src='design/icons/wheater.png' alt='wheater' style='left: -".$wheater_icon."px;'/>";
						?>
					</div>
					<div class='temperature'>24°</div>
					<p>Tue</p>
				</div>
			</div>
			<div class='cleaner'></div>
			
			<p class='copyright'>2019 <a href='www.hotheme.co' target='_blank'>newsportal.co</a></p>
			<div class='socials-wrapper'>
				<ul class='socials'>
					<li><a href='http://facebook.com/hipstacowboys' target='_blank'>facebook</a></li>
					<li><a href='http://twitter.com/hipstacowboys' target='_blank'>twitter</a></li>
				</ul>
			</div>

			<div class='cleaner'></div>
			
	    </div>