<!-- Header -->
<?php require('header.php'); ?>
	    
	    <!-- Content -->
	    <div class='container with-sidebar'>
		    <div class='content contact'>
		    	<h1>Contact</h1>
		    	
				<!-- Form -->
		    	<form action='php/contact-form.php' method='post' id='contact-form'>
		    		<div class='input-wrapper'><input type='text' class='contact-name' id='contact-name' name='contact-name' placeholder='Name' /><div class='status'><img src='design/icons/status.png' alt='status' class='status-name' /></div></div>
		    		<div class='input-wrapper'><input type='email' class='contact-email' id='contact-email' name='contact-email' placeholder='Email' /><div class='status'><img src='design/icons/status.png' alt='status' class='status-email' /></div></div>
		    		<div class='input-wrapper'><textarea class='contact-message' id='contact-message' name='contact-message' placeholder='Message'></textarea><div class='status'><img src='design/icons/status.png' alt='status' class='status-message' /></div></div>
		    		<input type='submit' class='custom-color-btn-back button' value='Send' />
		    	</form>

				<!-- Directions -->
				<div class='directions custom-color'>
					<div class='map' id='contact-map'></div>

					<!-- Embed map -->
					<script>
						function initialize() {
						  var myLatlng = new google.maps.LatLng(<?php echo $hotel_gps_latitude.",".$hotel_gps_longtitude; ?>);
						  var mapOptions = {
						    zoom: 4,
						    center: myLatlng,
						    scrollwheel: false
						  }
						  var map = new google.maps.Map(document.getElementById('contact-map'), mapOptions);

						  var marker = new google.maps.Marker({
						      position: myLatlng,
						      map: map,
						      title: 'Hello World!'
						  });
						}

						google.maps.event.addDomListener(window, 'load', initialize);

					</script>

					<p>
						<strong>287 Paradise Street</strong><br />
						EXJ 83K, Bronson<br />
						Iowa, United States
					</p>
					<p>
						<strong>GPS</strong><br />
						N10, 0139 829<br />
						E20, 9837 928
					</p>
					<p>
						<strong>Contact</strong><br />
						<a href='#'>www.hotheme.co</a><br />
						<a href='mailto:your@mail'>your@email</a>
					</p>
				</div>

				<!-- Exact directions -->
				<div class='exact-directions'>
					<h2 class='custom-color'>Directions</h2>
					<p>Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt.</p>	
				</div>
				<div class='cleaner'></div>
			</div>

		    <!-- Sidebar -->
		    <?php require('sidebar.php'); ?>

	    </div>
		<div class='cleaner'></div>
	    
	    <!-- Footer -->
	    <?php require('footer.php'); ?>
	    
    </div>
    
  </body>
</html>