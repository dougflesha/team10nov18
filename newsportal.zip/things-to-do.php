<!-- Header -->
<?php require('header.php'); ?>
	    
	    <!-- Content -->
	    <div class='content no-sidebar'>
	    	<h1>Things To Do</h1>
	    	<div class='list'>
		    	<!-- Item -->
		    	<div class='item'>
		    		<div class='img-wrapper'>
		    			<img src='design/items/poi_01/poi_01.jpg' alt='item' />
		    		</div>
		    		<div class='info'>
		    			<a href='poi.php'><h2 class='custom-color'>Point of interest</h2></a>
		    			
						<!-- Beds capacity
		    			<div class='beds-wrapper'>
		    				<div class='beds'>
			    				<?php
			    				// Beds capacity
			    				$beds = 2;

			    				for ($i=0; $i < $beds; $i++) { 
			    					echo "<div class='bed'></div>";
			    				}
								?>
		    				</div>
		    			</div>
		    			 -->
 
		    			<div class='distance-wrapper'>
		    				<div class='distance custom-color'>
			    				<?php
			    				// Distance
			    				$detail_gps_latitude = '41.006087';
								$detail_gps_longtitude = '-74.056694';
			    				
			    				$distance = calculateDistance($hotel_gps_latitude, $hotel_gps_longtitude, $detail_gps_latitude, $detail_gps_longtitude);

	    						echo round($distance, 2)."km";
								?>
		    				</div>
		    			</div>

		    			<p>Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor.
		    			</p>
		    			<a href='poi.php' class='button custom-color-btn-back'>Details</a>
		    			<!-- Tags 
		    			<span class='tags'>air condition, free wi-fi, bath, flat TV</span>-->
		    		</div>
		    		<div class='cleaner'></div>
		    	</div>
	    	</div>
	    </div>

	    <!-- Footer -->
	    <?php require('footer.php'); ?>
	    
    </div>
    
  </body>
</html>