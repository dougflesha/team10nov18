<!-- Header -->
<?php 
/*
This HTML Hotel Template is made by HipstaCowboys.com
If you want to download better, administrated Wordpress version, go for www.hotheme.co
Any feedback appreciated. Enjoy.
*/

require('header.php'); ?>
	    
	    <!-- Content -->
	    <div class='container with-sidebar'>
		    <div class='content reservation custom-color-back'>
		    	<h1>Reservation</h1>
		    	
				<!-- Form -->
		    	<form action='php/reservation-form.php' method='post' id='reservation-form'>
		    		<div class='input-wrapper'><select class='reservation-room' id='reservation-room' name='reservation-room'>
		    			<?php
		    			// Data from booking
		    			if (isset($_GET['booking-room'])) {
		    				echo "<option value='".$_GET['booking-room']."' selected>Superior Double Room ".$_GET['booking-room']."</option>";
		    			}

		    			?>
						
						<option value='1'>Superior Double Room 1</option>
		    			<option value='2'>Superior Double Room 2</option>
		    			<option value='3'>Superior Double Room 3</option>
		    			<option value='4'>Superior Double Room 4</option>
		    			<option value='5'>Superior Double Room 5</option>
		    		</select><div class='status'><img src='design/icons/status.png' alt='status' class='status-room' /></div></div>
		    		<div class='input-wrapper'><input type='text' class='reservation-checkin datepicker' id='reservation-checkin' name='reservation-checkin' value='<?php if(isset($_GET['booking-checkin'])){ echo $_GET['booking-checkin']; } ?>' placeholder='Check in' /><div class='datepicker-icon'></div><div class='status'><img src='design/icons/status.png' alt='status' class='status-checkin' /></div></div>
		    		<div class='input-wrapper'><input type='text' class='reservation-checkout datepicker' id='reservation-checkout' name='reservation-checkout' value='<?php if(isset($_GET['booking-checkout'])){ echo $_GET['booking-checkout']; } ?>' placeholder='Check out' /><div class='datepicker-icon'></div><div class='status'><img src='design/icons/status.png' alt='status' class='status-checkout' /></div></div>
		    		<div class='input-wrapper'><input type='text' class='reservation-people' id='reservation-people' name='reservation-people' placeholder='Number of people (optional)' /><div class='status'><img src='design/icons/status.png' alt='status' class='status-people' /></div></div>

		    		<div class='input-wrapper'><input type='text' class='reservation-name' id='reservation-name' name='reservation-name' placeholder='Name' /><div class='status'><img src='design/icons/status.png' alt='status' class='status-name' /></div></div>
		    		<div class='input-wrapper'><input type='email' class='reservation-email' id='reservation-email' name='reservation-email' placeholder='Email' /><div class='status'><img src='design/icons/status.png' alt='status' class='status-email' /></div></div>
		    		<div class='input-wrapper'><input type='text' class='reservation-phone' id='reservation-phone' name='reservation-phone' placeholder='Phone (optional)' /><div class='status'><img src='design/icons/status.png' alt='status' class='status-phone' /></div></div>
					<div class='input-wrapper'><textarea class='reservation-message' id='reservation-message' name='reservation-message' placeholder='Message (optional)'></textarea><div class='status'><img src='design/icons/status.png' alt='status' class='status-message' /></div></div>

		    		<input type='submit' class='custom-color-btn-back button' value='Ask for reservation' />
		    		<p>Or call on +44 948394 93829</p>
		    	</form>
				<div class='cleaner'></div>
			</div>

		    <!-- Sidebar -->
		    <?php require('sidebar.php'); ?>

	    </div>
		<div class='cleaner'></div>
	    
	    <!-- Footer -->
	    <?php require('footer.php'); ?>

    </div>
    
  </body>
</html>