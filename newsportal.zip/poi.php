<!-- Header -->
<?php require('header.php'); 

// Detail GPS
$detail_gps_latitude = '41.006087';
$detail_gps_longtitude = '-74.056694';

?>
	    
	    <!-- Content -->
	    <div class='container with-sidebar'>
		    <div class='content detail'>
		    	<h1>Point of interest</h1>

    			<!-- Distance -->
    			<div class='distance-wrapper'>
    				<div class='distance custom-color'>
	    				<?php
	    				// Distance

	    				$distance = calculateDistance($hotel_gps_latitude, $hotel_gps_longtitude, $detail_gps_latitude, $detail_gps_longtitude);

	    				echo round($distance, 2)."km";
						?>
    				</div>
    			</div>

				<!-- Main image -->
    			<div class='img-wrapper content-gallery'>
					<?php
						// Load images from Slider Directory
						$dirname = "design/items/poi_01/";
						$images = glob($dirname."*.jpg");
						
						foreach(array_reverse($images) as $image) {
							echo "<a href='".$image."'><img src='".$image."' alt='room' /><div class='open-gallery-trigger custom-color-btn-back button'>Open gallery</div></a>";
						}
					?>
	    			
	    		</div>

				<!-- Info -->
				<p>Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. <br /><br />

Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum. Sed ut perspiciatis unde omnis iste natus error sit voluptatem accusantium doloremque laudantium, totam rem aperiam, eaque ipsa quae ab illo inventore veritatis et quasi architecto beatae vitae dicta sunt explicabo. Nemo enim ipsam voluptatem quia voluptas sit aspernatur aut odit aut fugit, sed quia consequuntur magni dolores eos qui ratione voluptatem sequi nesciunt. Neque porro quisquam est, qui dolorem ipsum quia dolor sit amet, consectetur, adipisci velit, sed quia non numquam eius modi tempora incidunt ut labore et dolore magnam aliquam quaerat voluptatem.</p>

				<!-- Directions -->
				<div class='directions custom-color'>
					<div class='map' id='detail-map'></div>

					<!-- Embed map -->
					<script>
						function initialize() {
						  var myLatlng = new google.maps.LatLng(<?php echo $detail_gps_latitude.",".$detail_gps_longtitude; ?>);
						  var mapOptions = {
						    zoom: 4,
						    center: myLatlng,
						    scrollwheel: false
						  }
						  var map = new google.maps.Map(document.getElementById('detail-map'), mapOptions);

						  var marker = new google.maps.Marker({
						      position: myLatlng,
						      map: map,
						      title: 'Hello World!'
						  });
						}

						google.maps.event.addDomListener(window, 'load', initialize);

					</script>
					<p>
						<strong>287 Paradise Street</strong><br />
						EXJ 83K, Bronson<br />
						Iowa, United States
					</p>
					<p>
						<strong>GPS</strong><br />
						N10, 0139 829<br />
						E20, 9837 928
					</p>
					<p>
						<strong>Contact</strong><br />
						<a href='#'>www.hotheme.co</a>
					</p>
				</div>
				<div class='cleaner'></div>
			</div>

		    <!-- Sidebar -->
		    <?php require('sidebar.php'); ?>

	    </div>
		<div class='cleaner'></div>
	    
	    <!-- Footer -->
	    <?php require('footer.php'); ?>

    </div>
    
  </body>
</html>