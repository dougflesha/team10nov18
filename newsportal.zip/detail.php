<!-- Header -->
<?php require('header.php'); 

// Detail GPS
$detail_gps_latitude = '41.006087';
$detail_gps_longtitude = '-74.056694';

?>
	    
	    <!-- Content -->
	    <div class='container with-sidebar'>
		    <div class='content detail'>
		    	<h1>Superior Twin Room</h1>
		    	
		    	<!-- Beds -->
		    	<div class='beds-wrapper'>
    				<div class='beds'>
	    				<?php
	    				// Beds capacity
	    				$beds = 2;

	    				for ($i=0; $i < $beds; $i++) { 
	    					echo "<div class='bed'></div>";
	    				}
						?>
    				</div>
    			</div>

				<!-- Main image -->
    			<div class='img-wrapper content-gallery'>
					<?php
						// Load images from Slider Directory
						$dirname = "design/items/room_01/";
						$images = glob($dirname."*.jpg");
						
						foreach(array_reverse($images) as $image) {
							echo "<a href='".$image."'><img src='".$image."' alt='room' /><div class='open-gallery-trigger custom-color-btn-back button'>Open gallery</div></a>";
						}
					?>
	    			
	    		</div>

	    		<!-- Beds -->
	    		<div class='amenities'>
	    			<p><span class='custom-color'>Amenities: </span>air condition, free wi-fi, bath, flat TV</p>
				</div>

				<!-- Info -->
				<p>Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. <br /><br />

Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum. Sed ut perspiciatis unde omnis iste natus error sit voluptatem accusantium doloremque laudantium, totam rem aperiam, eaque ipsa quae ab illo inventore veritatis et quasi architecto beatae vitae dicta sunt explicabo. Nemo enim ipsam voluptatem quia voluptas sit aspernatur aut odit aut fugit, sed quia consequuntur magni dolores eos qui ratione voluptatem sequi nesciunt. Neque porro quisquam est, qui dolorem ipsum quia dolor sit amet, consectetur, adipisci velit, sed quia non numquam eius modi tempora incidunt ut labore et dolore magnam aliquam quaerat voluptatem.</p>

				<!-- Booking -->
				<div class='booking'>
					<div class='price custom-color'>$14<br /><span>per night</span></div>
					<form action='reservation.php' method='get'>
						<input type='hidden' id='booking-room' name='booking-room' value='3' />
						<div class='input-wrapper'><input type='text' class='booking-checkin datepicker' id='booking-checkin' name='booking-checkin' placeholder='14.06.2014' /><div class='datepicker-icon'></div></div>
						<div class='input-wrapper'><input type='text' class='booking-checkout datepicker' id='booking-checkout' name='booking-checkout' placeholder='14.06.2014' /><div class='datepicker-icon'></div></div>
						<input type='submit' class='booking-checkout custom-color-btn-back button' value='Book now' />

					</form>
				</div>

				<!-- Extended info -->
				<p class='extended-info'>Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat.</p>

				<div class='cleaner'></div>
			</div>

		    <!-- Sidebar -->
		    <?php require('sidebar.php'); ?>

	    </div>
		<div class='cleaner'></div>
	    
	    <!-- Footer -->
	    <?php require('footer.php'); ?>

    </div>
    
  </body>
</html>