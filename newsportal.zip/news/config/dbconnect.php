<?php
 	    $pdo = null;
    	    function connect_to_db()
    	    {
   		    $dbengine   = 'mysql';
    		    $dbhost     = 'localhost';
   		    $dbuser     = 'id8488817_news';
    		    $dbpassword = 'id8488817_group10';
    		    $dbname     = 'id8488817_news';
   
   		    try{
    			    $pdo = new PDO("".$dbengine.":host=$dbhost; dbname=$dbname", $dbuser,$dbpassword);
    			    return $pdo;
    		    }  
    		    catch (PDOException $e){
    			    $e->getMessage();
    		    }
    	    }