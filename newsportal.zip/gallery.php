<!-- Header -->
<?php require('header.php'); ?>
	    
	    <!-- Content -->
	    <div class='container with-sidebar'>
		    <div class='content'>
		    	<h1>Gallery</h1>
		    	<div class='list gallery content-gallery'>
		    		<?php
						// Load images from Slider Directory
						$dirname = "design/gallery/";
						$images = glob($dirname."*.jpg");

						$i = 1;
						
						foreach($images as $image) {
							echo "<a href='".$image."' class='img-wrapper'><img src='".$image."' alt='gallery' /></a>";
						}
					?>
		    	</div>
		    </div>

		    <!-- Sidebar -->
		    <?php require('sidebar.php'); ?>

	    </div>
		<div class='cleaner'></div>
	    
	    <!-- Footer -->
	    <?php require('footer.php'); ?>

    </div>
    
  </body>
</html>